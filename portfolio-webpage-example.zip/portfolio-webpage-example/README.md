# Portfolio Webpage Example

A Pen created on CodePen.

Original URL: [https://codepen.io/leonam-silva-de-souza/pen/vYowKqP](https://codepen.io/leonam-silva-de-souza/pen/vYowKqP).

Source: codewithsadee (https://www.youtube.com/watch?v=SoxmIlgf2zM)